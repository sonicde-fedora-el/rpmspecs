/**
 * SPDX-FileCopyrightText: 2010-2018 Daniel Nicoletti <dantti12@gmail.com>
 * SPDX-FileCopyrightText: 2022 Nicolas Fella <nicolas.fella@gmx.de>
 * SPDX-FileCopyrightText: 2023-2026 Mike Noe <noeerover@gmail.com>
 * SPDX-License-Identifier: GPL-2.0-or-later
 */

#ifndef PRINTERMANAGER_H
#define PRINTERMANAGER_H

#include <KQuickConfigModule>
#include <QObject>

struct DriverMatch {
    QString ppd;
    QString match;
};

using DriverMatchList = QList<DriverMatch>;

class KCupsRequest;
class PrinterManager : public KQuickConfigModule
{
    Q_OBJECT

    Q_PROPERTY(QVariantList remotePrinters READ remotePrinters NOTIFY remotePrintersLoaded)

    Q_PROPERTY(QVariantList recommendedDrivers READ recommendedDrivers NOTIFY recommendedDriversLoaded)

    Q_PROPERTY(QVariantMap serverSettings READ serverSettings NOTIFY serverSettingsChanged)

    Q_PROPERTY(bool serverSettingsLoaded READ serverSettingsLoaded NOTIFY serverSettingsChanged)

    Q_PROPERTY(bool shareConnectedPrinters READ shareConnectedPrinters NOTIFY serverSettingsChanged)

    Q_PROPERTY(bool allowPrintingFromInternet READ allowPrintingFromInternet NOTIFY serverSettingsChanged)

    Q_PROPERTY(bool allowRemoteAdmin READ allowRemoteAdmin NOTIFY serverSettingsChanged)

    Q_PROPERTY(bool allowUserCancelAnyJobs READ allowUserCancelAnyJobs NOTIFY serverSettingsChanged)

public:
    PrinterManager(QObject *parent, const KPluginMetaData &metaData, const QVariantList &args = QVariantList());

    Q_INVOKABLE static bool isIPPCapable(const QString &uri);
    Q_INVOKABLE static bool isSCPAvailable();

    bool shareConnectedPrinters() const;
    bool allowPrintingFromInternet() const;
    bool allowRemoteAdmin() const;
    bool allowUserCancelAnyJobs() const;

public Q_SLOTS:
    void loadPrinterPPD(const QString &name);
    void getServerSettings();
    void saveServerSettings(const QVariantMap &settings);

    void getRemotePrinters(const QString &uri, const QString &uriScheme);
    void getRecommendedDrivers(const QString &deviceId, const QString &makeAndModel, const QString &deviceUri);
    void clearRemotePrinters();
    void clearRecommendedDrivers();

Q_SIGNALS:
    void requestError(const QString &errorMessage);
    void serverSettingsChanged();
    void serverStopped();
    void serverStarted();
    void remotePrintersLoaded();
    void recommendedDriversLoaded();
    void ppdLoaded(const QVariantMap &printerPPD);
    void cmdAddPrinter();
    void cmdAddGroup();
    void cmdConfigurePrinter(const QString &name);

private:
    QVariantList remotePrinters() const;
    QVariantList recommendedDrivers() const;
    QVariantMap serverSettings() const;
    bool serverSettingsLoaded() const;

    QVariantMap m_serverSettings;
    bool m_serverSettingsLoaded = false;
    QVariantList m_remotePrinters;
    QVariantList m_recommendedDrivers;
    void processCmdLine(const QVariantList &args);
};

Q_DECLARE_METATYPE(DriverMatchList)
Q_DECLARE_METATYPE(DriverMatch)

#endif
