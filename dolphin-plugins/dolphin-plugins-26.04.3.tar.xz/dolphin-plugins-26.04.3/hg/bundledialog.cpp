/*
    SPDX-FileCopyrightText: 2011 Vishesh Yadav <vishesh3y@gmail.com>

    SPDX-License-Identifier: GPL-2.0-or-later
*/

#include "bundledialog.h"
#include "commitinfowidget.h"
#include "fileviewhgpluginsettings.h"
#include "hgwrapper.h"
#include "pathselector.h"

#include <KLocalizedString>
#include <KMessageBox>
#include <QCheckBox>
#include <QFileDialog>
#include <QGridLayout>
#include <QGroupBox>
#include <QLabel>
#include <QLineEdit>
#include <QListWidgetItem>
#include <QProcess>
#include <QVBoxLayout>
#include <QWidget>

HgBundleDialog::HgBundleDialog(QWidget *parent)
    : DialogBase(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, parent)
{
    this->setWindowTitle(xi18nc("@title:window", "<application>Hg</application> Bundle"));
    okButton()->setText(xi18nc("@action:button", "Bundle"));

    // Load saved settings
    FileViewHgPluginSettings *settings = FileViewHgPluginSettings::self();
    this->resize(QSize(settings->bundleDialogWidth(), settings->bundleDialogHeight()));
    //
    setupUI();

    // connections
    connect(this, SIGNAL(finished(int)), this, SLOT(saveGeometry()));
    connect(m_selectCommitButton, &QAbstractButton::clicked, this, &HgBundleDialog::slotSelectChangeset);
    connect(m_allChangesets, &QCheckBox::checkStateChanged, this, &HgBundleDialog::slotAllChangesCheckToggled);
}

void HgBundleDialog::setupUI()
{
    QVBoxLayout *mainLayout = new QVBoxLayout;

    // main
    m_pathSelect = new HgPathSelector;
    m_baseRevision = new QLineEdit;
    m_selectCommitButton = new QPushButton(xi18nc("@label:button", "Select Changeset"));
    QLabel *baseRevisionLabel = new QLabel(xi18nc("@label", "Base Revision (optional): "));
    m_allChangesets = new QCheckBox(xi18nc("@label", "Bundle all changesets in repository."));

    QGridLayout *bodyLayout = new QGridLayout;
    bodyLayout->addWidget(m_pathSelect, 0, 0, 2, 0);
    bodyLayout->addWidget(baseRevisionLabel, 2, 0);
    bodyLayout->addWidget(m_baseRevision, 2, 1);
    bodyLayout->addWidget(m_selectCommitButton, 2, 2);
    bodyLayout->addWidget(m_allChangesets, 3, 0, 2, 0);

    m_mainGroup = new QGroupBox;
    m_mainGroup->setLayout(bodyLayout);

    mainLayout->addWidget(m_mainGroup);

    // options
    m_optionGroup = new QGroupBox(xi18nc("@label:group", "Options"));
    m_optForce = new QCheckBox(xi18nc("@label:checkbox",
                                      "Run even when the destination is "
                                      "unrelated (force)"));
    m_optInsecure = new QCheckBox(xi18nc("@label:checkbox", "Do not verify server certificate"));

    QVBoxLayout *optionLayout = new QVBoxLayout;
    optionLayout->addWidget(m_optForce);
    optionLayout->addWidget(m_optInsecure);
    m_optionGroup->setLayout(optionLayout);

    mainLayout->addWidget(m_optionGroup);
    // end options

    layout()->insertLayout(0, mainLayout);
}

void HgBundleDialog::done(int r)
{
    if (r == QDialog::Accepted) {
        QString result = QFileDialog::getSaveFileName(this);
        if (result.length() > 0) {
            createBundle(result);
            QDialog::done(r);
        }
    } else {
        QDialog::done(r);
    }
}

void HgBundleDialog::createBundle(const QString &fileName)
{
    HgWrapper *hgw = HgWrapper::instance();
    QStringList args;

    if (m_allChangesets->checkState() == Qt::Checked) {
        args << QLatin1String("--all");
    } else {
        if (m_baseRevision->text().trimmed().length() > 0) {
            args << QLatin1String("--base");
            args << m_baseRevision->text().trimmed();
        }
    }

    if (m_optForce->checkState() == Qt::Checked) {
        args << QLatin1String("--force");
    }
    if (m_optInsecure->checkState() == Qt::Checked) {
        args << QLatin1String("--insecure");
    }

    args << fileName;
    args << m_pathSelect->remote();

    hgw->executeCommand(QLatin1String("bundle"), args);
}

void HgBundleDialog::saveGeometry()
{
    FileViewHgPluginSettings *settings = FileViewHgPluginSettings::self();
    settings->setBundleDialogHeight(this->height());
    settings->setBundleDialogWidth(this->width());
    settings->save();
}

void HgBundleDialog::loadCommits()
{
    HgWrapper *hgWrapper = HgWrapper::instance();

    // update heads list
    QProcess process;
    process.setWorkingDirectory(hgWrapper->getBaseDir());

    QStringList args;
    args << QLatin1String("log");
    args << QLatin1String("--template");
    args << QLatin1String(
        "{rev}\n{node|short}\n{branch}\n"
        "{author}\n{desc|firstline}\n");

    process.start(QLatin1String("hg"), args);
    process.waitForFinished();
    m_commitInfo->clear();

    const int FINAL = 5;
    char buffer[FINAL][1024];
    int count = 0;
    while (process.readLine(buffer[count], sizeof(buffer[count])) > 0) {
        if (count == FINAL - 1) {
            QString rev = QString::fromLocal8Bit(buffer[0]).trimmed();
            QString changeset = QString::fromLocal8Bit(buffer[1]).trimmed();
            QString branch = QString::fromLocal8Bit(buffer[2]).trimmed();
            QString author = QString::fromLocal8Bit(buffer[3]).trimmed();
            QString log = QString::fromLocal8Bit(buffer[4]).trimmed();

            QListWidgetItem *item = new QListWidgetItem;
            item->setData(Qt::DisplayRole, changeset);
            item->setData(Qt::UserRole + 1, rev);
            item->setData(Qt::UserRole + 2, branch);
            item->setData(Qt::UserRole + 3, author);
            item->setData(Qt::UserRole + 4, log);
            m_commitInfo->addItem(item);
        }
        count = (count + 1) % FINAL;
    }
}

void HgBundleDialog::slotSelectChangeset()
{
    DialogBase diag(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, this);
    diag.setWindowTitle(xi18nc("@title:window", "Select Changeset"));
    diag.okButton()->setText(xi18nc("@action:button", "Select"));

    diag.setMinimumWidth(700);

    m_commitInfo = new HgCommitInfoWidget;
    loadCommits();
    diag.layout()->insertWidget(0, m_commitInfo);

    if (diag.exec() == QDialog::Accepted) {
        m_baseRevision->setText(m_commitInfo->selectedChangeset());
    }
}

void HgBundleDialog::slotAllChangesCheckToggled(Qt::CheckState state)
{
    if (state == Qt::Checked) {
        m_selectCommitButton->setEnabled(false);
        m_baseRevision->setEnabled(false);
    } else {
        m_selectCommitButton->setEnabled(true);
        m_baseRevision->setEnabled(true);
    }
}

#include "moc_bundledialog.cpp"
