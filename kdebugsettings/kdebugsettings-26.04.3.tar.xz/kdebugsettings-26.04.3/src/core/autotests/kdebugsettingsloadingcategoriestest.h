/*
    SPDX-FileCopyrightText: 2019-2026 Laurent Montel <montel@kde.org>

    SPDX-License-Identifier: LGPL-2.0-or-later

*/

#pragma once

#include <QObject>

class KDebugSettingsLoadingCategoriesTest : public QObject
{
    Q_OBJECT
public:
    explicit KDebugSettingsLoadingCategoriesTest(QObject *parent = nullptr);
    ~KDebugSettingsLoadingCategoriesTest() override = default;
private Q_SLOTS:
    void shouldHaveDefaultValues();
};
