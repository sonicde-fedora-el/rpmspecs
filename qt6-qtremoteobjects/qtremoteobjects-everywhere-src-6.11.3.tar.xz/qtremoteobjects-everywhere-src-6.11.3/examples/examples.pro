TEMPLATE = subdirs
SUBDIRS = \
          remoteobjects
