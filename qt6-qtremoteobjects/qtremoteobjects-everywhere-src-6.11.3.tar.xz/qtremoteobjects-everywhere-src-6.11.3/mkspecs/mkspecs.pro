TEMPLATE = subdirs

SUBDIRS += features
