# Copyright (C) 2024 The Qt Company Ltd.
# SPDX-License-Identifier: BSD-3-Clause

add_subdirectory(utils)
add_subdirectory(theme)
add_subdirectory(global)
