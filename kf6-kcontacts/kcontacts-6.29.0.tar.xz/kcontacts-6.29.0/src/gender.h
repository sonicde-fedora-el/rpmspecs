/*
    This file is part of the KContacts framework.
    SPDX-FileCopyrightText: 2015-2019 Laurent Montel <montel@kde.org>

    SPDX-License-Identifier: LGPL-2.0-or-later
*/

#ifndef GENDER_H
#define GENDER_H
#include "kcontacts_export.h"
#include <QSharedDataPointer>
#include <QString>

namespace KContacts
{
/*!
 * \class KContacts::Gender
 * \inheaderfile KContacts/Gender
 * \inmodule KContacts
 *
 * \brief Class that holds a Gender for a contact.
 * \since 4.14.5
 */
class KCONTACTS_EXPORT Gender
{
    friend KCONTACTS_EXPORT QDataStream &operator<<(QDataStream &, const Gender &);
    friend KCONTACTS_EXPORT QDataStream &operator>>(QDataStream &, Gender &);

public:
    /*!
     * Creates an empty Gender object.
     */
    Gender();

    Gender(const Gender &other);

    /*!
     */
    Gender(const QString &gender);

    ~Gender();

    /*!
     */
    void setGender(const QString &gender);

    /*!
     */
    [[nodiscard]] QString gender() const;

    /*!
     */
    void setComment(const QString &comment);

    /*!
     */
    [[nodiscard]] QString comment() const;

    /*!
     */
    [[nodiscard]] bool isValid() const;

    /*!
     */
    [[nodiscard]] bool operator==(const Gender &other) const;

    /*!
     */
    [[nodiscard]] bool operator!=(const Gender &other) const;

    Gender &operator=(const Gender &other);

    /*!
     */
    [[nodiscard]] QString toString() const;

private:
    class Private;
    QSharedDataPointer<Private> d;
};

/*!
 * \relates KContacts::Gender
 */
KCONTACTS_EXPORT QDataStream &operator<<(QDataStream &stream, const Gender &object);

/*!
 * \relates KContacts::Gender
 */
KCONTACTS_EXPORT QDataStream &operator>>(QDataStream &stream, Gender &object);
}
Q_DECLARE_TYPEINFO(KContacts::Gender, Q_RELOCATABLE_TYPE);
#endif // GENDER_H
