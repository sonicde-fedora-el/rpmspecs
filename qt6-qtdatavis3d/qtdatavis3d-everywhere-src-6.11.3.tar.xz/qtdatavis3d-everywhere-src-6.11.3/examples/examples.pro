TEMPLATE = subdirs
SUBDIRS += datavisualization
