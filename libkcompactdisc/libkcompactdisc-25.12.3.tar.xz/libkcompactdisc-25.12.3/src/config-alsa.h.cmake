#cmakedefine HAVE_ALSA
