// Copyright (C) 2017 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial OR LGPL-3.0-only OR GPL-2.0-only OR GPL-3.0-only
// Qt-Security score:significant reason:default

#ifndef QMODBUS_SYMBOLS_P_H
#define QMODBUS_SYMBOLS_P_H

//
//  W A R N I N G
//  -------------
//
// This file is not part of the Qt API.  It exists purely as an
// implementation detail.  This header file may change from version to
// version without notice, or even be removed.
//
// We mean it.
//

#include <QtCore/qtypes.h>

// MBAP header: transaction id (2), protocol id (2), length (2), unit id (1)
constexpr int mbpaHeaderSize = 7;
// The 253 byte maximum PDU plus the MBAP header
constexpr int maxBytesModbusADU = 260;

// The length field counts the Unit Identifier, which mbpaHeaderSize already
// includes, so the frame is one byte shorter than the two added together.
constexpr int mbapAduSize(quint16 mbapLength)
{
    return mbpaHeaderSize + mbapLength - 1;
}

// The smallest frame carries a one byte PDU, the function code alone. The
// largest is a maxBytesModbusADU sized frame.
constexpr bool isValidAduSize(int aduSize)
{
    return aduSize >= mbpaHeaderSize + 1 && aduSize <= maxBytesModbusADU;
}

enum Coil {
    On = 0xff00,
    Off = 0x0000
};

namespace Diagnostics {

enum SubFunctionCode {
    ReturnQueryData = 0x0000,
    RestartCommunicationsOption = 0x0001,
    ReturnDiagnosticRegister = 0x0002,
    ChangeAsciiInputDelimiter = 0x0003,
    ForceListenOnlyMode = 0x0004,
    ClearCountersAndDiagnosticRegister = 0x000a,
    ReturnBusMessageCount = 0x000b,
    ReturnBusCommunicationErrorCount = 0x000c,  // CRC error counter
    ReturnBusExceptionErrorCount = 0x000d,
    ReturnServerMessageCount = 0x000e,
    ReturnServerNoResponseCount = 0x000f,
    ReturnServerNAKCount = 0x0010,
    ReturnServerBusyCount = 0x0011,
    ReturnBusCharacterOverrunCount = 0x0012,
    ClearOverrunCounterAndFlag = 0x0014
};

}

namespace EncapsulatedInterfaceTransport {

enum SubFunctionCode {
    CanOpenGeneralReference = 0x0D,
    ReadDeviceIdentification = 0x0E
};

}

#endif // QMODBUS_SYMBOLS_P_H
