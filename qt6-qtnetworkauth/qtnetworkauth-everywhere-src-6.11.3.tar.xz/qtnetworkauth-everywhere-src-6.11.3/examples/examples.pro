TEMPLATE = subdirs
SUBDIRS += oauth
